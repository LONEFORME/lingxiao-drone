
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'MSP432' 
 * Target:  'MSP432P4xx_MainFlash256kB' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "msp.h"


#endif /* RTE_COMPONENTS_H */
